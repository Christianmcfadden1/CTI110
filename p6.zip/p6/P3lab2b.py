import turtle          
win = turtle.Screen()  
t = turtle.Turtle()

# add some display options
t.pensize(3)            # increase pensize (takes integer)
t.pencolor("purple")     # set pencolor (takes string)
t.shape("turtle")

#commands from here to the last line can be replaced
# triangle, sides are 360 / 3 = 120 degrees

t.left(180)
t.forward(30)
t.right(90)
t.forward(30)
t.left(90)
t.forward(30)


t.left(90)
t.forward(30)
t.right(120)
t.forward(15)
t.left(90)
t.forward(15)
t.right(120)
t.forward(30)



# end commands
win.mainloop()
