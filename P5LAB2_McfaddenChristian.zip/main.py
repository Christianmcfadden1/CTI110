feet = 2.5
def feet_to_steps(ftWalk):
    steps = ftWalk / feet
    return int(steps)

if __name__ == '__main__':
    
    ftWalk = float(input())
    print(feet_to_steps(ftWalk))