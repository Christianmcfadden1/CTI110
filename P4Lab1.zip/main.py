import re
user_text = input()


print(len(re.sub(r'[ ,.!]+', '', user_text)))


