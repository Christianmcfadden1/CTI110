

def laps_to_miles(laps):
    mile = laps / 4
    return mile


 

if __name__ == '__main__':
    laps = float(input())
    print("{:.2f}".format(laps_to_miles(laps))) 